package com.xedrux.cclouds.web.controllers;

import com.xedrux.cclouds.web.dao.RolDAO;
import com.xedrux.cclouds.web.entities.CcloudsRol;
import com.xedrux.cclouds.web.exceptions.EntityNotFoundException;
import com.xedrux.cclouds.web.exceptions.UnableToCreateEntityException;
import java.util.Collection;
import java.util.HashMap;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Isidro Rodríguez Gamez
 */
@RestController
@RequestMapping("/admin/rol")
public class RolController {

    @Autowired
    RolDAO rolDAO;

    public void setRolDAO(RolDAO DAO) {
        this.rolDAO = DAO;
    }

    @RequestMapping(value = "/", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String, Object> getAllRols() {
        Collection<CcloudsRol> rols = rolDAO.getAllRols();
        HashMap<String, Object> response = new HashMap<>();
        response.put("rols", rols);
        return response;
    }

    @RequestMapping(value = "/id={id}", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HashMap<String, Object>> getRol(@ModelAttribute("id") Long id) {
        HashMap<String, Object> response = new HashMap<>();
        CcloudsRol rol = rolDAO.getRol(id);
        if (rol != null) {
            response.put("rol", rol);
        } else {
            response.put("message", "No hay rol con id " + id);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/name={name}", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HashMap<String, Object>> getRolByName(@ModelAttribute("name") String name) {
        HashMap<String, Object> response = new HashMap<>();
        CcloudsRol rol = rolDAO.findRolByName(name);
        if (rol != null) {
            response.put("rol", rol);

        } else {
            response.put("message", "No hay rol con nombre " + name);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @ResponseStatus(HttpStatus.CREATED)
    @RequestMapping(value = "/", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String, Object> insertRol(
            @RequestBody @Valid CcloudsRol rol, BindingResult result)
            throws UnableToCreateEntityException {
        HashMap<String, Object> response = new HashMap<>();
        if (result.hasErrors()) {
            throw new UnableToCreateEntityException("Unable to create rol. "
                    + "There are wrong fields.",
                    result.getFieldErrors());
        } else {
            long id = rolDAO.insertRol(rol);
            response.put("id", id);
        }
        return response;
    }

    @RequestMapping(value = "/{Id}", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String, Object> updateRol(
            @ModelAttribute("Id") int id,
            @RequestBody @Valid CcloudsRol rol,
            BindingResult result)
            throws EntityNotFoundException, UnableToCreateEntityException {
        HashMap<String, Object> response = new HashMap<>();
        if (result.hasErrors()) {
            throw new UnableToCreateEntityException("Unable to update rol.",
                    result.getFieldErrors());
        } else {
            rol.setIdRol(id);
            if (rolDAO.updateRol(rol)) {
                response.put("success", true);
            } else {
                throw new EntityNotFoundException("Can't update. Rol not found.");
            }
        }
        return response;
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public void deleteRol(@ModelAttribute("id") long id) throws
            EntityNotFoundException {
        if (!rolDAO.deleteRol(id)) {
            throw new EntityNotFoundException(
                    "Couldn't delete. There is no rol with id:" + id);
        }
    }
}
