package com.xedrux.cclouds.web.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Admin
 */

public class CcloudsAgencia implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long idAgencia;
    @Size(max = 255)
    private String nombreAgencia;
    @Size(max = 500)
    private String observacionAgencia;
    private Integer idRepresentanteAgencia;
    private long idSucursal;

    public CcloudsAgencia() {
    }

    public Long getIdAgencia() {
        return idAgencia;
    }

    public void setIdAgencia(Long idAgencia) {
        this.idAgencia = idAgencia;
    }

    
    public String getNombreAgencia() {
        return nombreAgencia;
    }

    public void setNombreAgencia(String nombreAgencia) {
        this.nombreAgencia = nombreAgencia;
    }

    public String getObservacionAgencia() {
        return observacionAgencia;
    }

    public void setObservacionAgencia(String observacionAgencia) {
        this.observacionAgencia = observacionAgencia;
    }

    public Integer getIdRepresentanteAgencia() {
        return idRepresentanteAgencia;
    }

    public void setIdRepresentanteAgencia(Integer idRepresentanteAgencia) {
        this.idRepresentanteAgencia = idRepresentanteAgencia;
    }

    public long getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(long idSucursal) {
        this.idSucursal = idSucursal;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAgencia != null ? idAgencia.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CcloudsAgencia)) {
            return false;
        }
        CcloudsAgencia other = (CcloudsAgencia) object;
        if ((this.idAgencia == null && other.idAgencia != null) || (this.idAgencia != null && !this.idAgencia.equals(other.idAgencia))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.xedrux.cclouds.web.entities.CcloudsAgencia[ idAgencia=" + idAgencia + " ]";
    }
    
}
