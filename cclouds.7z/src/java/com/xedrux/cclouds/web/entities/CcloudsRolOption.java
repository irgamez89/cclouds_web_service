package com.xedrux.cclouds.web.entities;

import javax.validation.constraints.NotNull;

/**
 *
 * @author Isidro Rodríguez Gamez
 */
public class CcloudsRolOption {
    
    @NotNull
    private Integer id;
    private Integer idOption;
    private Integer idRol;

    public CcloudsRolOption() {
    }

    public CcloudsRolOption(Integer id, Integer idModule, Integer idRol) {
        this.id = id;
        this.idOption = idModule;
        this.idRol = idRol;
    }

    public CcloudsRolOption(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdModule() {
        return idOption;
    }

    public void setIdModule(Integer idModule) {
        this.idOption = idModule;
    }

    public Integer getIdRol() {
        return idRol;
    }

    public void setIdRol(Integer idRol) {
        this.idRol = idRol;
    }


    @Override
    public String toString() {
        return "com.xedrux.cclouds.web.entities.CcloudsRolModule[ id=" + id + " ]";
    }
    
}
